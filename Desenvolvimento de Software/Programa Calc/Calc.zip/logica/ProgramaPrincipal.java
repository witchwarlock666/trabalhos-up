//Fabricio Bertoncello Filho e Felipe Lacerda

package logica;

import grafica.FrmCalc;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        FrmCalc frm = new FrmCalc();
        frm.setVisible(true);
    }
}
